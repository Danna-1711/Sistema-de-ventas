
import Config.Conexion;
import Model.Cliente;
import Model.ClienteDAO;
import Model.Empleado;
import Model.EmpleadoDAO;
import Model.VentaDAO;
import java.util.List;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author jodon
 */
public class prueba {
    public static void main(String[] args) {
        VentaDAO dao = new VentaDAO();
        System.out.println(dao.GenerarSerie());
    }
}
